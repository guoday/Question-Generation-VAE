import ujson as json
import os
from tqdm import tqdm
import nltk
from nltk.tokenize import word_tokenize
import pickle as pkl
import collections
import numpy
def count_lines(fname):
    with open(fname) as f:
        return sum(1 for line in f)

def build_dictionary(filepaths,dst_path,lowercase=False):
    word_freqs = collections.OrderedDict()
    for filepath in filepaths:
        print ('Processing', filepath)
        with open(filepath, 'r') as f:
            for line in f:
                if lowercase:
                    line = line.lower()
                words_in = line.strip().split()
                for w in words_in:
                    if w not in word_freqs:
                        word_freqs[w] = 0
                    word_freqs[w] += 1

    sorted_words= sorted(word_freqs.items(), key=lambda d:d[1], reverse=True)
    worddict = collections.OrderedDict()
    

    for ii, ww in enumerate(sorted_words):
        worddict[ww[0]] = ii + 4
    print('Size of dictionary: '+str(len(worddict)))
    with open(dst_path[0], 'wb') as f:
        pkl.dump(worddict, f)
    with open(dst_path[1],'w') as f:
        for word in worddict:
            f.write(word+'\n')
        
if __name__=='__main__':
    from_path="QA/WikiSQL/annotated/"
    to_path="QG/data/"
    for split in ['train','dev','test','sql_gen']:
        print('Preprocess '+split+' data')
        max_len_in=0
        min_len_in=10000
        max_len_out=0
        min_len_out=10000
        fsplit=os.path.join(from_path,split)+'.jsonl'
        fin=os.path.join(to_path,split)+'.in'
        fout=os.path.join(to_path,split)+'.out'
        with open(fsplit) as fs,open(fin,'w') as f_in,open(fout,'w') as f_out:
            for line in tqdm(fs,total=count_lines(fsplit)):
                try:
                	temp=json.loads(line)
                except: 
                        continue
                seq_in=' '.join(temp['seq_output']['words']).lower()
                seq_out=' '.join(temp['question']['words']).lower()
                seq_in=' '.join(word_tokenize(seq_in))
                seq_out=' '.join(word_tokenize(seq_out))
                f_in.write(seq_in+'\n')
                f_out.write(seq_out+'\n')
                max_len_in=max(max_len_in,len(seq_in.split()))
                max_len_out=max(max_len_out,len(seq_out.split()))
                min_len_in=min(min_len_in,len(seq_in.split()))
                min_len_out=min(min_len_out,len(seq_out.split()))
        print(split+' data max min len input:',max_len_in,min_len_in)
        print(split+' data max min len output:',max_len_out,min_len_out)
        print("-"*80)
    print('Building dictionary .....')
    build_dictionary([os.path.join(to_path,'train.in'),os.path.join(to_path,'train.out')],[os.path.join(to_path,'vocab.pkl'),os.path.join(to_path,'vocab.in')])
    print('Building dictionary done!')           
    print("-"*80)           
                
    
